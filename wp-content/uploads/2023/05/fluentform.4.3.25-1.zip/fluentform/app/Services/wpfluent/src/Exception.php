<?php namespace WpFluent;

class Exception extends \Exception
{

}
