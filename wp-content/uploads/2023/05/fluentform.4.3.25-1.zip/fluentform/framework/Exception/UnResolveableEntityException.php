<?php

namespace FluentForm\Framework\Exception;

class UnResolveableEntityException extends \Exception
{
	// ...
}