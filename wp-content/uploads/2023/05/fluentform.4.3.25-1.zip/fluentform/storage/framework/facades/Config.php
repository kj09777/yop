<?php

namespace FluentForm;

use FluentForm\Framework\Foundation\AppFacade;

class Config extends AppFacade
{
	static $key = 'config';
}
