<?php

namespace FluentForm;

use FluentForm\Framework\Foundation\AppFacade;

class App extends AppFacade
{
	static $key = 'app';
}
