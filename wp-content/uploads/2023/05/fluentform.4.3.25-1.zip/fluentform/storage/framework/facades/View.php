<?php

namespace FluentForm;

use FluentForm\Framework\Foundation\AppFacade;

class View extends AppFacade
{
	static $key = 'view';
}
