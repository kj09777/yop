<?php

namespace FluentForm;

use FluentForm\Framework\Foundation\AppFacade;

class Request extends AppFacade
{
	static $key = 'request';
}
