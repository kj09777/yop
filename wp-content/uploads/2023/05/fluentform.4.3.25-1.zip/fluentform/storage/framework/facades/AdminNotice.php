<?php

namespace FluentForm;

use FluentForm\Framework\Foundation\AppFacade;

class AdminNotice extends AppFacade
{
	static $key = 'adminNotice';
}
